import{C as t}from"./index-C6W_P6j1.js";const o={getNotices:()=>t.get("/config/notices"),getChangelog:()=>t.get("/config/updates")};export{o as c};
