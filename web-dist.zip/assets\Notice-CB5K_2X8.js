import{r as h}from"./rolldown-runtime-b3L32Ng1.js";import{Gt as x,Lt as f,jt as j,kt as g,lt as y,on as S,pn as I,w as N}from"./antd-DypD9b84.js";import{d as C}from"./vendor-DrnhTMUC.js";import{n as T}from"./format-COYL_e_l.js";var i=h(I(),1),e=C(),b="_pageContainer_1tivc_3",w="_header_1tivc_11",D="_title_1tivc_18",R="_unreadCount_1tivc_32",$="_noticeList_1tivc_42",E="_noticeCard_1tivc_49",O="_unread_1tivc_32",L="_expanded_1tivc_76",H="_noticeHeader_1tivc_81",A="_headerLeft_1tivc_89",M="_unreadDot_1tivc_98",k="_pulse_1tivc_1",q="_noticeTitle_1tivc_113",z="_typeTag_1tivc_126",F="_noticeMeta_1tivc_132",G="_metaItem_1tivc_138",K="_readStatus_1tivc_146",P="_noticeContent_1tivc_151",U="_summaryText_1tivc_156",Y="_fullContent_1tivc_167",B="_toggleHint_1tivc_180",J="_emptyState_1tivc_188",t={pageContainer:b,header:w,title:D,unreadCount:R,noticeList:$,noticeCard:E,unread:O,expanded:L,noticeHeader:H,headerLeft:A,unreadDot:M,pulse:k,noticeTitle:q,typeTag:z,noticeMeta:F,metaItem:G,readStatus:K,noticeContent:P,summaryText:U,fullContent:Y,toggleHint:B,emptyState:J},Q={important:{label:"重要",color:"#ff4d4f"},update:{label:"更新",color:"#1890ff"},activity:{label:"活动",color:"#00b26a"},normal:{label:"通知",color:"#999"}},l=[{id:1,title:"时光绿径待办 v2.0 正式发布",summary:"全新 UI 设计、性能优化、多项新功能上线...",content:`亲爱的用户们，我们很高兴地宣布时光绿径待办 v2.0 正式版本已发布！

本次更新包含以下重大改进：

1. 全新设计的界面，更加清爽美观
2. 性能大幅提升，操作更流畅
3. 新增协作功能，支持团队共享
4. 新增数据分析模块
5. 优化移动端体验
6. 修复已知问题

感谢大家一直以来的支持和反馈！`,publishTime:new Date(Date.now()-864e5).toISOString(),isRead:!1,type:"important"},{id:2,title:"系统维护通知",summary:"计划于本周六凌晨进行系统升级维护...",content:`为提供更好的服务体验，我们计划于本周六（2025年1月18日）凌晨 02:00-06:00 进行系统升级维护。

维护期间以下功能可能暂时不可用：
- 数据同步功能
- 协作相关功能
- 用户注册/登录

请提前做好安排，给您带来的不便敬请谅解。`,publishTime:new Date(Date.now()-1728e5).toISOString(),isRead:!1,type:"important"},{id:3,title:"新功能：AI 智能助手上线",summary:"集成 AI 助手，帮你智能规划待办事项...",content:`我们很高兴地宣布 AI 智能助手功能正式上线！

AI 助手可以帮您：
- 智能分析待办优先级
- 提供完成建议和时间预估
- 自动生成周报和月报
- 回答关于待办管理的各种问题

快来试试吧！点击工具栏中的 AI 图标即可使用。`,publishTime:new Date(Date.now()-6048e5).toISOString(),isRead:!0,type:"update"},{id:4,title:"春节活动预告",summary:"参与活动赢取高级会员...",content:`新春佳节即将到来，我们准备了丰富的活动等你来参与！

活动时间：1月20日 - 2月10日
活动内容：
1. 完成每日签到领取积分
2. 邀请好友双方获得奖励
3. 分享使用心得有机会获得高级会员

具体规则请关注后续公告。`,publishTime:new Date(Date.now()-1296e6).toISOString(),isRead:!0,type:"activity"},{id:5,title:"隐私政策更新说明",summary:"我们对隐私政策进行了部分调整...",content:`为了更好地保护您的个人信息安全，我们对隐私政策进行了如下更新：

1. 明确了数据收集范围和使用目的
2. 增加了用户数据导出功能说明
3. 完善了数据删除机制
4. 更新了第三方服务共享政策

您可以随时在设置中查看完整的隐私政策。如有任何疑问，欢迎联系客服。`,publishTime:new Date(Date.now()-2592e6).toISOString(),isRead:!0,type:"normal"}],ee=()=>{const[c,_]=(0,i.useState)(null),[s,v]=(0,i.useState)(()=>new Set(l.filter(a=>a.isRead).map(a=>a.id))),o=(0,i.useCallback)(a=>{_(n=>n===a?null:a),s.has(a)||v(n=>new Set([...n,a]))},[s]),p=(0,i.useCallback)(a=>{const n=c===a.id,r=s.has(a.id),d=Q[a.type];return(0,e.jsxs)(x,{className:`${t.noticeCard} ${r?"":t.unread} ${n?t.expanded:""}`,onClick:()=>o(a.id),children:[(0,e.jsxs)("div",{className:t.noticeHeader,children:[(0,e.jsxs)("div",{className:t.headerLeft,children:[!r&&(0,e.jsx)("span",{className:t.unreadDot}),(0,e.jsx)("h3",{className:t.noticeTitle,children:a.title})]}),(0,e.jsx)(y,{color:d.color,className:t.typeTag,children:d.label})]}),(0,e.jsxs)("div",{className:t.noticeMeta,children:[(0,e.jsxs)("span",{className:t.metaItem,children:[(0,e.jsx)(f,{})," ",T(a.publishTime)]}),(0,e.jsxs)("span",{className:`${t.metaItem} ${r?t.readStatus:""}`,children:[(0,e.jsx)(g,{})," ",r?"已读":"未读"]})]}),(0,e.jsx)("div",{className:`${t.noticeContent} ${n?t.contentExpanded:""}`,children:n?(0,e.jsx)("p",{className:t.fullContent,children:a.content.split(`
`).map((u,m)=>(0,e.jsxs)(i.Fragment,{children:[u,m<a.content.split(`
`).length-1&&(0,e.jsx)("br",{})]},m))}):(0,e.jsx)("p",{className:t.summaryText,children:a.summary??a.content.slice(0,120)+"..."})}),(0,e.jsx)("div",{className:t.toggleHint,children:n?"收起":"点击查看全文"})]},a.id)},[c,s,o]);return(0,e.jsxs)("div",{className:t.pageContainer,children:[(0,e.jsxs)("div",{className:t.header,children:[(0,e.jsxs)("h1",{className:t.title,children:[(0,e.jsx)(N,{})," 公告中心"]}),(0,e.jsxs)("span",{className:t.unreadCount,children:[l.length-s.size," 条未读"]})]}),l.length===0?(0,e.jsx)(S,{image:(0,e.jsx)(j,{style:{fontSize:64,color:"#ddd"}}),description:"暂无公告",className:t.emptyState}):(0,e.jsx)("div",{className:t.noticeList,children:l.map(p)})]})};export{ee as default};
