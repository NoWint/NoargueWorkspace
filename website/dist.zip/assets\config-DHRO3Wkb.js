import{B as t}from"./index-BKYx8md-.js";const o={getNotices:()=>t.get("/config/notices"),getChangelog:()=>t.get("/config/updates")};export{o as c};
